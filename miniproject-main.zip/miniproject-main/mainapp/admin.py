from django.contrib import admin
from .models import WaterATM, Booking, UserProfile

admin.site.register(WaterATM)
admin.site.register(Booking)
admin.site.register(UserProfile)
