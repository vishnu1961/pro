from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from .models import WaterATM, Booking
from django.contrib.auth.decorators import login_required
from .models import UserProfile
from django.contrib import messages
from .models import Register
def home(request):
    return render(request, 'home.html')  # Public home page with login/register buttons

def register(request):
    if request.method == 'POST':
        user = User.objects.create_user(
            username=request.POST['email'],
            email=request.POST['email'],
            password=request.POST['password'],
            first_name=request.POST['name']
        )
        UserProfile.objects.create(
            user=user,
            address=request.POST['address'],
            place=request.POST['place'],
            phone=request.POST['phone']
        )
        return redirect('login')
    return render(request, 'register.html')
    
def login_view(request):
    if request.method == 'POST':
        email = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(username=email, password=password)
        if user is not None:
            login(request, user)
            request.session['user_id'] = user.id
            request.session['user_name'] = user.first_name
            return redirect('user_home')  # ✅ redirects to user_home
        else:
            messages.error(request, 'Invalid email or password')
            return redirect('login')

    return render(request, 'login.html')


@login_required
def dashboard(request):  # This was previously home()
    atms = WaterATM.objects.filter(status="Active")
    return render(request, 'index.html', {'atms': atms})

@login_required
def book_atm(request, atm_id):
    Booking.objects.create(user=request.user, atm_id=atm_id, time_slot='10:00 AM')
    return redirect('dashboard')

# mainapp/views.py
def user_home(request):
    if 'user_id' in request.session:
        return render(request, 'user_home.html', {'name': request.session['user_name']})
    else:
        return redirect('login')

def logout_view(request):
    logout(request)
    return redirect('login')  # or wherever you want the user to go after logout
