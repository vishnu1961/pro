from django.contrib import admin
from .models import WaterATM, Booking
admin.site.register(WaterATM)
admin.site.register(Booking)