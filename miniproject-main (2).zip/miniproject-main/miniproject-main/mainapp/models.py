from django.db import models
from django.contrib.auth.models import User
class WaterATM(models.Model):
    location = models.CharField(max_length=255)
    gmap_link = models.URLField(blank=True, null=True)
    total_capacity = models.IntegerField()   # in liters
    available_water = models.IntegerField()  # in liters

    @property
    def status(self):
        return "Available" if self.available_water > 0 else "Unavailable"

    def __str__(self):
        return f"{self.location} - {self.status}"
class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    atm = models.ForeignKey(WaterATM, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=True)
    time_slot = models.CharField(max_length=50)
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.TextField()
    place = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)

    def __str__(self):
        return self.user.username
class Register(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    place = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.name
