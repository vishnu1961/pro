from django.contrib import admin
from .models import WaterATM, Booking

@admin.register(WaterATM)
class WaterATMAdmin(admin.ModelAdmin):
    list_display = ("location", "total_capacity", "available_water", "status")
admin.site.register(Booking)

