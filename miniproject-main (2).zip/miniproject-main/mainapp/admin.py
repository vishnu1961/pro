from django.contrib import admin
from .models import WaterATM, Booking, UserProfile
@admin.register(WaterATM)
class WaterATMAdmin(admin.ModelAdmin):
    list_display = ("location","gmap_link","total_capacity", "available_water", "status")
admin.site.register(Booking)
admin.site.register(UserProfile)
