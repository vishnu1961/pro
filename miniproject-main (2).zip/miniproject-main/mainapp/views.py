from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import WaterATM, Booking, UserProfile

def home(request):
    return render(request, 'home.html')  # Public home page with login/register buttons

def register(request):
    if request.method == 'POST':
        user = User.objects.create_user(
            username=request.POST['email'],
            email=request.POST['email'],
            password=request.POST['password'],
            first_name=request.POST['name']
        )
        UserProfile.objects.create(
            user=user,
            address=request.POST['address'],
            place=request.POST['place'],
            phone=request.POST['phone']
        )
        return redirect('login')
    return render(request, 'register.html')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')  # Changed from 'email' to 'username'
        password = request.POST.get('password')

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('user_home')  # ✅ redirects to user_home
        else:
            messages.error(request, 'Invalid email or password')
            return redirect('login')

    return render(request, 'login.html')

@login_required
def dashboard(request):
    # Show all ATMs added by admin
    atms = WaterATM.objects.all()  # or filter(status="Active") if you want only active
    return render(request, 'index.html', {'atms': atms})


@login_required
def book_atm(request, atm_id):
    if not Booking.objects.filter(user=request.user, atm_id=atm_id).exists():
        Booking.objects.create(user=request.user, atm_id=atm_id, time_slot='10:00 AM')
    return redirect('dashboard')

@login_required
def user_home(request):
    return render(request, 'user_home.html', {'name': request.user.first_name})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def bulk_order(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        address = request.POST.get('address')
        quantity = request.POST.get('quantity')
        phone = request.POST.get('phone')

        # Here you can save to database (create a BulkOrder model)
        messages.success(request, 'Bulk order placed successfully!')
        return redirect('user_home')

    return render(request, 'bulk_order.html')
from .forms import WaterATMForm
@login_required
def add_atm(request):
    if request.method == "POST":
        form = WaterATMForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('dashboard')  # after saving, go back to dashboard
    else:
        form = WaterATMForm()
    return render(request, 'add_atm.html', {'form': form})