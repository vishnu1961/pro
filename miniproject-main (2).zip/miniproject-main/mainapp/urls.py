from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  # Public home
    path('login/', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),
    path('book/<int:atm_id>/', views.book_atm, name='book_atm'),
    path('home/', views.user_home, name='user_home'),
    path('bulk_order/', views.bulk_order, name='bulk_order'),
    path('add_atm/', views.add_atm, name='add_atm'),

]
