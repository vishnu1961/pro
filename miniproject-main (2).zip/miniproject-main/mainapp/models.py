from django.db import models
from django.contrib.auth.models import User
# models.py
class WaterATM(models.Model):
    location = models.CharField(max_length=200)
    total_capacity = models.IntegerField()
    available_water = models.IntegerField()
    gmap_link = models.URLField(default='https://example.com')

    image = models.ImageField(upload_to='atm_images/', default='default_images/placeholder.png')

    booking = models.BooleanField(default=False)

    STATUS_CHOICES = (
        ('Active', 'Active'),
        ('Inactive', 'Inactive'),
    )
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Active')

class Booking(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    atm = models.ForeignKey(WaterATM, on_delete=models.CASCADE, related_name='bookings')
    time_slot = models.CharField(max_length=20)

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    address = models.TextField()
    place = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)

    def __str__(self):
        return self.user.username
class Register(models.Model):
    name = models.CharField(max_length=100)
    address = models.TextField()
    place = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    password = models.CharField(max_length=100)

    def __str__(self):
        return self.name