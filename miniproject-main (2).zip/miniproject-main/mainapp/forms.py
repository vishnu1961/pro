from django import forms
from .models import WaterATM

class WaterATMForm(forms.ModelForm):
    class Meta:
        model = WaterATM
        fields = ['location', 'gmap_link', 'total_capacity', 'available_water', 'image']
